import java.util.*;
public class principal {
public static void main (String [] args){
	System.out.println("Calculo de si un Numero es Par o Impar");
	Scanner entrada = new Scanner(System.in);
    System.out.print("Introduzca un Numero: ");
    int n = entrada.nextInt();
    if (n%2==0) { System.out.println("El Numero es Par");
    } else  System.out.println("El Numero es Impar");
        }
        
    }

